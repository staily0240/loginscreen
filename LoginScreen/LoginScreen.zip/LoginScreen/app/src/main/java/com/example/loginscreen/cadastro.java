package com.example.loginscreen;

public class cadastro {
}
